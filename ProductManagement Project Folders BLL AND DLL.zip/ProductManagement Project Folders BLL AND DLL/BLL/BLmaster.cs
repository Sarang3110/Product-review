﻿using DLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class BLmaster
    {

        DLmaster ObjAtteDL = new DLmaster();

        public bool InsertProductDetails(string productname, string productdescription, string productprice, string productstock,string Category, DateTime createdat, DateTime updatedat)
        {
            return ObjAtteDL.InsertProductDetails(productname, productdescription, productprice, productstock, Category, createdat, updatedat);
        }

        public DataTable GetProductDetailsById(int prouductId)
        {
            return ObjAtteDL.GetProductDetailsById(prouductId);

        }

        public DataTable GetProductDetails(int categoryId, int minPrice, int maxPrice, string availability)
        {
            return ObjAtteDL.GetProductDetails(categoryId, minPrice, maxPrice, availability);

        }

        public bool UpdateProduct(string productid,string productname, string productdescription, string productprice, string productstock, string category, DateTime updatedat)
        {
            return ObjAtteDL.UpdateProduct(productid,productname, productdescription, productprice, productstock, category, updatedat);
        }

        public bool InsertProductReviews(int productId, int userId, int rating, string comment, string sentiment)
        {
            return ObjAtteDL.InsertProductReviews(productId, userId, rating, comment, sentiment);
        }

        public bool DeleteProduct(int prouductId)
        {
            return ObjAtteDL.DeleteProduct(prouductId);

        }

        public bool InsertOrderDetails(int productid, int orderquantity,int price, string name,string email,string mobileno,string address)
        {
            return ObjAtteDL.InsertOrderDetails(productid, orderquantity,price, name,email,mobileno,address);

        }
    }
}
