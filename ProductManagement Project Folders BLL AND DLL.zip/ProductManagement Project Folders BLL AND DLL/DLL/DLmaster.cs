﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL
{
    public class DLmaster
    {

        Connection Con = new Connection();
        public bool InsertProductDetails(string productname, string productdescription, string productprice, string productstock,string Category, DateTime createdat, DateTime updatedat)
        {
            bool flag = false;
            try
            {

                int productId = 0;

                string Queary = @"INSERT INTO Product (ProductName, ProductDescription, Price, StockQuantity, CreatedAt, UpdatedAt) 
                  VALUES ('" + productname + "', '" + productdescription + "', '" + productprice + "', '" + productstock + "', '" + createdat + "', '" + updatedat + "'); SELECT SCOPE_IDENTITY(); ";

                // Check if lastWorkingDay is null, if so, insert NULL in the query, otherwise insert the date

                //string query2 = @"insert into loginmaster (emp_id, roleid, usename, password, isactive) values('" + empid + "', '2', '" + username + "','" + password + "', 'Y')";
                //Con.ExecuteNonQuery(query2);
               object result=Con.Execute_ScalarQuery(Queary);

                if (result != null)
                {
                    productId = Convert.ToInt32(result);
                }

                if (productId > 0)
                {
                    string query2 = @"insert into ProductCategory values('" + productId + "', '" + Category + "')";
                    flag=Con.ExecuteNonQuery(query2);
                }

            }
            catch (Exception ex)
            {
                // Handle exceptions
            }
            return flag;
        }

        public bool InsertProductReviews(int productId, int userId, int rating, string comment, string sentiment)
        {
            bool flag=false;
            try
            {
                string Queary = @"Insert into ProductReviewsDetails  Values('" + productId + "', '" + userId + "','" + rating + "','" + comment + "' ,'" + sentiment + "','" + DateTime.Now + "')";

                flag = Con.ExecuteNonQuery(Queary);

            }

            catch (Exception ex)
            {
                // Handle exceptions
            }
            return flag;
        }

        public bool InsertOrderDetails(int productid,int orderquantity ,int price, string name,string email,string mobileno,string address)
        {
            bool flag = false;
            int UserId = 0;

            try
            {

                string Queary = @"Insert into Users  Values('" + name + "', '" + email + "','" + mobileno + "','" + address + "',0); SELECT SCOPE_IDENTITY();";

                object data = Con.Execute_ScalarQuery(Queary);

                if (data != null)
                {
                    UserId = Convert.ToInt32(data);
                }

                if (UserId > 0)
                {

                    string queary2 = @"Insert into OrderDetails(ProductId,Quantity,Price,UserId,CreatedOn)  Values('" + productid + "','" + orderquantity + "','" + price + "','" + UserId + "', '" + DateTime.Now + "')";

                    flag =Con.ExecuteNonQuery(queary2);
                }

            }

            catch (Exception ex)
            {
                // Handle exceptions
            }
            return flag;
        }

        public DataTable GetProductDetails(int categoryId, int minPrice, int maxPrice, string availability)
        {
            DataTable Dt = new DataTable();
            try
            {
                Hashtable hs = new Hashtable();
                hs.Add("@CategoryId", categoryId);
                hs.Add("@MinPrice", minPrice);
                hs.Add("@MaxPrice", maxPrice);
                hs.Add("@Availability", availability);
                Dt = Con.GetDataFromSP("sp_GetFilteredProducts", hs);
            }
            catch (Exception ex)
            {
            }
            return Dt;
        }

        public bool DeleteProduct(int prouductId)
        {
            bool flag = false;
            try
            {


                string Queary = @" Delete from Product where ProductID=" + prouductId;

                // Check if lastWorkingDay is null, if so, insert NULL in the query, otherwise insert the date

                string query2=@" Delete from ProductCategory where ProductId=" + prouductId;
                 Con.ExecuteNonQuery(Queary);
                flag = Con.ExecuteNonQuery(query2);
            }
            catch (Exception ex)
            {
                // Handle exceptions
            }
            return flag;

        }

        public bool UpdateProduct(string productid,  string productname, string productdescription, string productprice, string category, string productstock,DateTime updatedat)
        {

            bool flag = false;
            try
            {


                string Queary = @"Update Product SET  ProductName='" + productname + "',ProductDescription='" + productdescription + "',Price='" + productprice + "',StockQuantity = '" + productstock + "', UpdatedAt = '" + updatedat + "' where ProductID='"+productid+"' ";

              

                string query2 = @"update ProductCategory set CategoryId='" + category + "'  where ProductId = " + productid;

                Con.ExecuteNonQuery(query2);
                flag = Con.ExecuteNonQuery(Queary);
            }
            catch (Exception ex)
            {
                // Handle exceptions
            }
            return flag;
        }

        public DataTable GetProductDetailsById(int prouductId)
        {
            DataTable dt = new DataTable();
            try
            {
                string Queary = "select p.ProductName,p.ProductDescription,p.Price,p.StockQuantity,cat.CategoryId from Product  as p INNER JOIN ProductCategory AS pat ON pat.ProductId = p.ProductID INNER JOIN Categories AS cat ON cat.CategoryId = pat.CategoryId   where p.ProductID=" + prouductId;
                dt = Con.GetDataFromQuery(Queary);
            }
            catch (Exception ex)
            {
            }
            return dt;
        }
    }
}
